package com.example.assignment;

public class DataClass {

    String name, lec, email, date, id, time ,desc;

    public DataClass(){

    }

    public String getName() {

        return name;
    }
    public void setName(String name) {
        this.name = name;
    }

    public String getLec() {

        return lec;
    }

    public void setLec(String lec) {
        this.lec = lec;
    }

    public String getEmail() {

        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getDate() {

        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getId() {

        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getTime() {

        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getDesc() {

        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public DataClass(String name, String lec, String email, String date, String id, String time, String desc){
        this.name = name;
        this.lec = lec;
        this.email = email;
        this.date = date;
        this.id = id;
        this.time = time;
        this.desc = desc;
    }
}

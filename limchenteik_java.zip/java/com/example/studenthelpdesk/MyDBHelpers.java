package com.example.studenthelpdesk;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import java.util.List;
import java.util.ArrayList;
import androidx.annotation.Nullable;

public class MyDBHelpers extends SQLiteOpenHelper {
    private static String DATABASE_NAME = "STUDENT_HELP_DESKS";
    static int DATABASE_VERSION = 6; // Increment the version number
    static String TABLE_NAME = "USERS";
    static final String KEY_userName = "userName";
    static final String KEY_ID = "id";
    static final String KEY_EMAIL = "email";
    static final String KEY_PASSWORD = "password";

    static String TABLE_NAME_LECTURERS = "LECTURERS";
    static final String KEY_LECTURER_NAME = "lecturer_userName";
    static final String KEY_LECTURER_ID = "lecturer_id";
    static final String KEY_LECTURER_EMAIL = "lecturer_email";
    static final String KEY_LECTURER_PASSWORD = "lecturer_password";

    static String TABLE_NAME_APPOINTMENTS = "APPOINTMENT";
    static final String KEY_APPOINTMENT_ID = "appointment_id";
    static final String KEY_APPOINTMENT_NAME = "name";
    static final String KEY_APPOINTMENT_EMAIL = "email";
    static final String KEY_STUDENT_ID = "student_id";
    static final String KEY_APPOINTMENT_DATE = "date";
    static final String KEY_APPOINTMENT_TIME = "time";
    static final String KEY_APPOINTMENT_DESCRIPTION = "description";

    public MyDBHelpers(@Nullable Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        db.execSQL("CREATE TABLE " + TABLE_NAME + "(" + KEY_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " + KEY_EMAIL + " TEXT, " + KEY_PASSWORD + " TEXT, " + KEY_userName + " TEXT)");
        db.execSQL("CREATE TABLE " + TABLE_NAME_LECTURERS + "(" + KEY_LECTURER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " + KEY_LECTURER_EMAIL + " TEXT, " + KEY_LECTURER_PASSWORD + " TEXT, " + KEY_LECTURER_NAME + " TEXT)");
        db.execSQL("CREATE TABLE " + TABLE_NAME_APPOINTMENTS + "(" + KEY_APPOINTMENT_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " + KEY_APPOINTMENT_NAME + " TEXT, " + KEY_APPOINTMENT_EMAIL + " TEXT, " + KEY_STUDENT_ID + " TEXT, " + KEY_LECTURER_NAME + " TEXT, " + KEY_APPOINTMENT_DATE + " TEXT, " + KEY_APPOINTMENT_TIME + " TEXT, " + KEY_APPOINTMENT_DESCRIPTION + " TEXT)");

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        if (oldVersion < 2) {
            // Add the "username" column to the existing table
            db.execSQL("ALTER TABLE " + TABLE_NAME + " ADD COLUMN " + KEY_userName + " TEXT");
        }

        if (oldVersion <4) {
            // Create the "APPOINTMENT" table if the old version is less than 4
            db.execSQL("CREATE TABLE " + TABLE_NAME_APPOINTMENTS + "(" +
                    KEY_APPOINTMENT_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    KEY_APPOINTMENT_NAME + " TEXT, " +
                    KEY_APPOINTMENT_EMAIL + " TEXT, " +
                    KEY_STUDENT_ID + " TEXT, " +
                    KEY_LECTURER_NAME + " TEXT, " +
                    KEY_APPOINTMENT_DATE + " TEXT, " +
                    KEY_APPOINTMENT_TIME + " TEXT, " +
                    KEY_APPOINTMENT_DESCRIPTION + " TEXT)");
        }
    }
    // Example usage of getReadableDatabase

}
package com.example.shd;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class MyDBHelpers extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "FeedbackDatabase";
    private static final int DATABASE_VERSION = 1;

    public MyDBHelpers(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // Create your table(s) here
        String createTableQuery = "CREATE TABLE IF NOT EXISTS feedback_table ("
                + "_id INTEGER PRIMARY KEY AUTOINCREMENT,"
                + "feedback_text TEXT,"
                + "rating INTEGER);";
        db.execSQL(createTableQuery);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Handle database upgrades here
        // You can drop existing tables and recreate them, or make any other necessary changes
        db.execSQL("DROP TABLE IF EXISTS feedback_table");
        onCreate(db);
    }
}

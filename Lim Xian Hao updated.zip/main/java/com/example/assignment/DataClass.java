package com.example.assignment;

public class DataClass {

    private String name;
    private String lec;
    private String email;
    private String date;
    private String id;
    private String time;
    private String desc;

    public String getName() {
        return name;
    }
    public String getLec() {
        return lec;
    }

    public String getEmail() {
        return email;
    }

    public String getDate() {
        return date;
    }

    public String getId() {
        return id;
    }

    public String getTime() {
        return time;
    }

    public String getDesc() {
        return desc;
    }

    public DataClass(String name, String lec, String email, String date, String id, String time, String desc){
        this.name = name;
        this.lec = lec;
        this.email = email;
        this.date = date;
        this.id = id;
        this.time = time;
        this.desc = desc;
    }
}

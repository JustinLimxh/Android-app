package com.example.assignment;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Notification;
import android.content.Intent;
import android.content.res.Resources;
import android.media.Rating;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.google.firebase.Firebase;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.nio.file.attribute.UserPrincipalLookupService;

public class Appointment extends AppCompatActivity {

    FirebaseDatabase db;
    DatabaseReference reference;
    TextView textView2;
    TextView textView3;
    TextView textView4;
    TextView textView5;
    TextView textView6;
    TextView textView7;
    EditText editText1;
    EditText editText2;
    EditText editText3;
    EditText editText4;
    EditText editText5;
    EditText editText6;
    EditText editText7;
    Button buttonSub;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_appointment);

        textView2 = findViewById(R.id.textView2);
        textView3 = findViewById(R.id.textView3);
        textView4 = findViewById(R.id.textView4);
        textView5 = findViewById(R.id.textView5);
        textView6 = findViewById(R.id.textView6);
        textView7 = findViewById(R.id.textView7);
        editText1 = findViewById(R.id.nameInput);
        editText2 = findViewById(R.id.lecInput);
        editText3 = findViewById(R.id.emailInput);
        editText4 = findViewById(R.id.dateInput);
        editText5 = findViewById(R.id.studentIDInput);
        editText6 = findViewById(R.id.timeInput);
        editText7 = findViewById(R.id.descriptionInput);
        buttonSub = findViewById(R.id.createBtn);

        textView2.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                Intent intent = new Intent(getApplicationContext(), Books.class);
                startActivity(intent);
                finish();
            }
        });
        textView3.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                Intent intent = new Intent(getApplicationContext(), Select_App.class);
                startActivity(intent);
                finish();
            }
        });
        textView4.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                Intent intent = new Intent(getApplicationContext(), Notification.class);
                startActivity(intent);
                finish();
            }
        });
        textView5.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                Intent intent = new Intent(getApplicationContext(), Select_App.class);
                startActivity(intent);
                finish();
            }
        });
        textView6.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                Intent intent = new Intent(getApplicationContext(), Resources.class);
                startActivity(intent);
                finish();
            }
        });
        textView7.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                Intent intent = new Intent(getApplicationContext(), Rating.class);
                startActivity(intent);
                finish();
            }
        });

        buttonSub.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){

                String name = editText1.getText().toString();
                String lec = editText2.getText().toString();
                String email = editText3.getText().toString();
                String date = editText4.getText().toString();
                String id = editText5.getText().toString();
                String time = editText6.getText().toString();
                String desc = editText7.getText().toString();

                if(!name.isEmpty() && !lec.isEmpty() && !email.isEmpty() && !date.isEmpty() && !id.isEmpty() && !time.isEmpty() && !desc.isEmpty())

                    Users users = new Users(name,email,id);
                    db = FirebaseDatabase.getInstance();
                    reference = db.getReference("Users");

            }
        });
    }
}
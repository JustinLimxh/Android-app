package com.example.studenthelpdesk.;

import android.content.Intent;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class notification extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notification);

        Button homeBtn = findViewById(R.id.homeBtn);

        TextView textView2 = findViewById(R.id.textView2);
        TextView textView3 = findViewById(R.id.textView3);
        TextView textView4 = findViewById(R.id.textView4);
        TextView textView5 = findViewById(R.id.textView5);
        TextView textView6 = findViewById(R.id.textView6);
        TextView textView7 = findViewById(R.id.textView7);

        textView2.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                Intent intent = new Intent(getApplicationContext(), book.class);
                startActivity(intent);
                finish();
            }
        });
        textView3.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                Intent intent = new Intent(getApplicationContext(), appointment.class);
                startActivity(intent);
                finish();
            }
        });
        textView4.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                Intent intent = new Intent(getApplicationContext(), notification.class);
                startActivity(intent);
                finish();
            }
        });
        textView5.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                Intent intent = new Intent(getApplicationContext(), studentqna.class);
                startActivity(intent);
                finish();
            }
        });
        textView6.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                Intent intent = new Intent(getApplicationContext(), resource.class);
                startActivity(intent);
                finish();
            }
        });
        textView7.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                Intent intent = new Intent(getApplicationContext(), rating.class);
                startActivity(intent);
                finish();
            }
        });

        homeBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Create an Intent to switch to the SignUpActivity
                Intent intent = new Intent(notification.this, studentHomepage.class);
                startActivity(intent);
            }
        });

        // Assuming you have received notifications from the database
        // For demonstration, let's create a sample data
        String[] notifications = {"Notification 1", "Notification 2", "Notification 3"};

        // Get the container
        LinearLayout notificationContainer = findViewById(R.id.notificationContainer);

        // Dynamically add notifications to the container
        for (String notification : notifications) {
            // Create a TextView for the notification
            TextView notificationTextView = new TextView(this);
            notificationTextView.setText(notification);
            notificationTextView.setTextSize(15);
            notificationTextView.setTextColor(getResources().getColor(android.R.color.black));
            notificationTextView.setGravity(Gravity.CENTER);
            notificationContainer.addView(notificationTextView);
        }
        TextView qAndATextView = findViewById(R.id.textView5);
        // Set an OnClickListener to navigate to studentnotification.xml when clicked
        qAndATextView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Start the StudentNotification activity
                Intent intent = new Intent(notification.this, studentqna.class);
                startActivity(intent);
            }
        });
    }
}
